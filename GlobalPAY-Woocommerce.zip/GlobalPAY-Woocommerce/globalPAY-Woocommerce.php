<?php
/*
Plugin Name:  GlobalPAY WooCommerce
Plugin URI: https://www.zenithbank.com.gh
Description:  GlobalPAY by Zenithbank https://www.zenithbank.com.gh/api.globalpay
Author: Robert Adwini
Author URI: 
Version:1.0.0
Date: 05/05/2017
*/

add_action('plugins_loaded', 'woocomerce_global_pay', 0);
function woocomerce_global_pay()
{
    if (!class_exists('WC_Payment_Gateway')) {
        return;
    }
    load_plugin_textdomain('wc_globalpay', false, dirname(plugin_basename(__file__)) .'/languages');       

    /**
     * Gateway class
     **/
    class wc_globalpay extends WC_Payment_Gateway
    {
        var $api_username;
        var $api_password;
        var $testmode = "";

        public function __construct()
        {
            // Load the settings.
            $this->id = 'wc_globalpay';
            $this->has_fields = false;
            $this->return_url = add_query_arg('wc-api', 'wc_globalpay', home_url('/')); //Only using server hosted
            $this->liveurl = 'https://www.zenithbank.com.gh/GlobalPAY_api/api/Pay';
            $this->testurl = 'https://www.zenithbank.com.gh/globalpay_api/api/sandbox/Test';
            // Create plugin fields and settings
            $this->init_form_fields();
            $this->init_settings();
            // Get setting values
            foreach ($this->settings as $key => $val) {
                $this->$key = $val;
            }
            $this->icon = WP_PLUGIN_URL . "/" . plugin_basename(dirname(__file__)) . '/images/logo.gif';
            $this->method_title = __('GlobalPAY Zenithbank', 'woocommerce');
            add_action('woocommerce_api_wc_wc_globalpay', array($this, '_response_process'));
            // Hooks
            add_action('woocommerce_update_options_payment_gateways', array($this, 'process_admin_options'));
            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        }

        /**
         * Initialize Gateway Settings Form Fields
         */
        function init_form_fields()
        {
            $this->form_fields = array(
                'title' => array(
                    'title' => __('Title', 'woocommerce'),
                    'type' => 'text',
                    'description' => __('This controls the title which the user sees during checkout.', 'woocommerce'),
                    'default' => __('GlobalPAY Zenithbank', 'woocommerce')
                    ),
                'enabled' => array(
                    'title' => __('Enable/Disable', 'woocommerce'),
                    'label' => __('Enable', 'woocommerce'),
                    'type' => 'checkbox',
                    'description' => '',
                    'default' => 'no'
                    ),
                'description' => array(
                    'title' => __('Description', 'woocommerce'),
                    'type' => 'textarea',
                    'description' => __('This controls the description which the user sees during checkout.', 'woocommerce'),
                    'default' => 'Pay with your credit card or debit card.'
                    ),                
                'GlobalPayID' => array(
                    'title' => __('GlobalPay ID', 'woocommerce'),
                    'type' => 'text',
                    'description' => __('', 'woocommerce'),
                    'default' => ''
                    ),                
                'gz_order_status' => array(
                    'title' => __('Order Status', 'woocommerce'),                    
                    'type' => 'select',
                    'description' => __('If you selling digital product you should set to 2 .', 'woocommerce'),
                    'options' => array('1' => 'Processing', '2' => 'Completed'),
                    'default' => '1',
                    ),
                'testmode' => array(
                    'title' => __('Test Mode', 'woocommerce'),
                    'label' => __('Enable Test', 'woocommerce'),
                    'type' => 'checkbox',
                    'description' => __('Process transactions in Test Mode via the Test account  .', 'woocommerce'),
                    'default' => 'no'
                    )

                );

        }


        /**
         * Admin Panel Options 
         * - Options for bits like 'title' and availability on a country-by-country basis
         */
        function admin_options()
        {
            ?>
            <h3><?php _e('GlobalPAY Zenithbank', 'woocommerce'); ?></h3>
            <p>
            <?php _e('GlobalPAY Zenithbank works by adding credit card fields on the checkout and then sending the details to GlobalPAY Zenithbank for verification.',
                        'woocommerce'); ?>
            </p>
            <table class="form-table">
            <?php $this->
            generate_settings_html(); ?>
            </table>
            <!--/.form-table-->
            <?php
        }

       /**
         * Payment form on checkout page
         */
        function payment_fields()
        {           

                //Merchant hosted
                if ($this->testmode == 'yes') {
                    _e('<strong>TEST MODE/ Bank ENABLED</strong>', 'woocommerce');                    
                }
                if ($this->description)
                    echo wpautop(wptexturize($this->description));                
            ?> 
            <fieldset>
                <p class="form-row form-row-first">
                    <label for=""><?php echo __("Credit Card Type", 'woocommerce') ?>
                    <span class="required">*</span></label>
                    <select name="gz_card_type" id="cc-card-type">
                        <option value="visa"><?php _e('Visa', 'woocommerce') ?></option>
                        <option value="mastercard"><?php _e('MasterCard', 'woocommerce') ?></option>
                    </select>                    
                </p>
                <p class="form-row form-row-first">
                    <label for="gz_card_number"><?php echo __("Credit Card number", 'woocommerce') ?>
                    <span class="required">*</span></label>
                    <input type="text" class="input-text" name="gz_card_number"/>
                </p>
                <div class="clear">
                </div>
                <p class="form-row form-row-first">
                    <label for="cc-expire-month"><?php echo __("Expiration date", 'woocommerce') ?>
                    <span class="required">*</span></label>
                    <select name="gz_card_expiration_month" id="cc-expire-month">
                        <option value=""><?php _e('Month', 'woocommerce') ?></option>
                        <?php
                            $months = array();
                            for ($i = 1; $i <= 12; $i++) {
                                $timestamp = mktime(0, 0, 0, $i, 1);
                                $months[date('m', $timestamp)] = date('F', $timestamp);
                            }
                            foreach ($months as $num =>
                         $name) { printf('
                        <option value="%s">%s</option>
                        ', $num, $name); } ?>
                    </select>
                    <select name="gz_card_expiration_year" id="cc-expire-year">
                        <option value=""><?php _e('Year', 'woocommerce') ?></option>
                        <?php
                            $years = array();
                            for ($i = date('Y'); $i <= date('Y') + 15; $i++) {
                                printf('<option value="%u">
                        %u</option>
                        ', $i, $i); } ?>
                    </select>
                </p>
                <p class="form-row form-row-last">
                    <label for="gz_card_csc"><?php _e("Card security code", 'woocommerce') ?>
                    <span class="required">*</span></label>
                    <input type="text" class="input-text" id="gz_card_csc" name="gz_card_csc" maxlength="4" style="width:90px"/>
                    <span class="help gz_card_csc_description"></span>
                </p>
                <div class="clear"></div>
            </fieldset>         
            <?php            
        }


        /**
         * Process the payment
         */
        function process_payment($order_id)
        {
            global $woocommerce;
            $response = array();
            $order = new WC_Order($order_id);
                try {
                    $url = $this->liveurl;                                        
                    $amount = (float)($order->order_total); // ."00";
                    $card_number_type = isset($_POST['gz_card_type']) ? $_POST['gz_card_type'] : '';
                    $card_number = isset($_POST['gz_card_number']) ? $_POST['gz_card_number'] : '';
                    $card_csc = isset($_POST['gz_card_csc']) ? $_POST['gz_card_csc'] : '';
                    $card_exp_month = isset($_POST['gz_card_expiration_month']) ? $_POST['gz_card_expiration_month'] : '';
                    $expirationYear = isset($_POST['gz_card_expiration_year']) ? $_POST['gz_card_expiration_year'] : '';
                    if (strlen($expirationYear) == 4)
                        $expirationYear = substr($expirationYear, 2, 4);
                    if ($this->testmode == 'yes') {
                        $url = $this->testurl;
                    }
                    $request_fields['PaymentRequest'] = array(
                        'Merchant' => array(        
                            'GlobalPayID' => $this->GlobalPayID
                            ),
                        'Card' => array(
                                'CardNumber' => $card_number,
                                'CardExpiryMonth' => $card_exp_month,
                                'CardExpiryYear' => $expirationYear,
                                'CardCvv' => $card_csc
                            ),
                        'Payment' => array(
                            'Description' => 'Payment use GlobalPAY Zenithbank',
                            'ReferenceID' => "REF_".$order_id,
                            'OrderID' => $order_id,
                            'Amount' => $amount
                            ),
                        'Mode' => "Visa"
                        );                  
                    $data_string = json_encode($request_fields);

                    $ch = curl_init($url);                                                                      
                    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
                    curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);                                                               
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                                                                      
                    curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
                        'Content-Type: application/json',                                                                                
                        'Content-Length: ' . strlen($data_string))                                                                       
                    );                                                                                                                   
                    $response = curl_exec($ch);

                } catch (exception $e) {
                    wc_add_notice(__('There was a connection error', 'woocommerce') . ': "' . $e->getMessage() . '"');
                    return;
                }

                $responOBJ = json_decode($response);
                $responOBJ = json_decode($responOBJ);
                if ($responOBJ->PaymentResponse->PaymentStatus == "Approved"):
                    $order->add_order_note(__('GlobalPAY Zenithbank payment completed', 'woocommerce') .
                        ' (REF ID: ' . $responOBJ->PaymentResponse->referenceID  . ')');
                    $order->payment_complete();
                    if($this->gz_order_status == 2) {
                        // Mark order as refunded COMPLETED
                        $order->update_status('completed', __('Payment completed', 'woocommerce'));
                    }
                    $woocommerce->cart->empty_cart();
                    // Return thankyou redirect
                    return array(
                        'result'    => 'success',
                        'redirect'  => $this->get_return_url( $order )
                    );  
								
                else:   
					
					if ($responOBJ->PaymentResponse->PaymentStatus == "vbv required")
					{
						$paymentURL = $responOBJ->PaymentResponse->reason;
                        header( "Location: ".$paymentURL  );
					}
					else
					{
						$cancelNote = __('GlobalPAY Zenithbank  payment failed', 'woocommerce') . ' (REF ID: ' .
                        $responOBJ->PaymentResponse->referenceID . '). ' . __('Payment was rejected due to an error',
                        'woocommerce') . ': "' . $responOBJ->PaymentResponse->Reason . '". ';

                    $order->add_order_note($cancelNote);

                    wc_add_notice(__('Payment error', 'woocommerce') . ': ' . $responOBJ->PaymentResponse->Reason . '','error');
					}						                                        
                endif;
                
        }

        function thankyou()
        {
            if ($this->instructions != '') {
                echo wpautop($this->instructions);
            }
        }

        /**
         * Validate the payment form
         */
        function validate_fields()
        {
            global $woocommerce;
            if ($this->payment_mode == 1) {
                //Merchant hosted
                $card_type = isset($_POST['gz_card_type']) ? $_POST['gz_card_type'] : '';
                $card_number = isset($_POST['gz_card_number']) ? $_POST['gz_card_number'] :
                    '';
                $card_csc = isset($_POST['gz_card_csc']) ? $_POST['gz_card_csc'] : '';
                $card_exp_month = isset($_POST['gz_card_expiration_month']) ? $_POST['gz_card_expiration_month'] :
                    '';
                $card_exp_year = isset($_POST['gz_card_expiration_year']) ? $_POST['gz_card_expiration_year'] :
                    '';
                // Check card security code
                if (!ctype_digit($card_csc)) {
                    wc_add_notice(__('Card security code is invalid (only digits are allowed)',
                        'woocommerce'));
                    return false;
                }                
                // Check card expiration data
                if (!ctype_digit($card_exp_month) || !ctype_digit($card_exp_year) || $card_exp_month >
                    12 || $card_exp_month < 1 || $card_exp_year < date('Y') || $card_exp_year > date
                    ('Y') + 20) {
                    wc_add_notice(__('Card expiration date is invalid', 'woocommerce'));
                    return false;
                }
                // Check card number
                $card_number = str_replace(array(' ', '-'), '', $card_number);
                if (empty($card_number) || !ctype_digit($card_number)) {
                    wc_add_notice(__('Card number is invalid', 'woocommerce'));
                    return false;
                }
                return true;
            } else
                return true;
        }        

        /**
        * Validate plugin settings
        */
        function validate_settings()
        { // if need
            return true;
        }

        /**
        * Get user's IP address
        */
        function get_user_ip()
        {
            $ret = "";
            if (!empty($_SERVER['HTTP_X_FORWARD_FOR'])) {
                $ret =  $_SERVER['HTTP_X_FORWARD_FOR'];
            } else {
                $ret =  $_SERVER['REMOTE_ADDR'];
            }
            return $ret;
        }


    } // class


    /**
    * Add the Gateway to WooCommerce
    **/
    function woocommerce_add_globalpay_gate($methods)
    {
        $methods[] = 'WC_GLOBALPAY';
        return $methods;
    }
    // Adding Gateway to WooCommerce Gateways
    add_filter('woocommerce_payment_gateways', 'woocommerce_add_globalpay_gate');
} // end woocommerce_GlobalPAY 
?>