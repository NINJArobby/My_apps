### INSTALL GLOBALPAY WOOCOMMERCE PAYMENT GATEWAY
1. Upload the files to your Plugin directory.
2. Sign in to your Wordpress admin.
3. Click **Woocommerce Setting** tab and **Payments Gateway subtab**. OR Click Checkout tab ( Woocomerce 2.1.x) 
4. Click **GlobalPAY Setting** to config plguin  .
5. Enter your **GLOBALPAY ID:**. Exam test:GPZENTEST118
6. Select  **Test Mode**.
7. Save your changes.

CARD TEST
Type: Visa
Number: 54444444444444 
EXP: 09/17  
CVV: 058

TEST CASE 
Put amount in these case will return
+ Success Response : Any number
+ Fail Response : 1000