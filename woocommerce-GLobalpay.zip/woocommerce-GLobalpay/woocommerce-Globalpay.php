<?php
/**
Plugin Name:  GlobalPAY WooCommerce
Plugin URI: https://www.zenithbank.com.gh
Description:  GlobalPAY by Zenithbank 
Author: Robert Adwini
Author URI: https://www.zenithbank.com.gh/api.globalpay
Version:1.0.0
Date: 05/05/2017
 
 */
 
 
 class Merchant
 {
 	public $GlobalPayID="";
 }

 class Card
 {
 	public $CardNumber="";
 	public $CardExpiryMonth="";
 	public $CardExpiryYear="";
 	public $CardCvv="";
 }

 class Payment
 {
 	public $Description="";
 	public $ReferenceID="";
 	public $OrderID="";
 	public $Amount="";
 }
class PaymentRequest
 {
 	public $Mode="";
 	public $merchant;
 	public $card;
 	public $payment;

	public function __construct(){
		$this->merchant = new Merchant;
		$this->card = new Card;
		$this->payment = new Payment;
	}
 }
class RootObject
 {
 	public $paymentRequest ;
	public function __construct()
	{
		$this->paymentRequest = new PaymentRequest;
	}
}
defined( 'ABSPATH' ) or exit;


// Make sure WooCommerce is active
if ( ! in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	return;
}


/**
 * Add the gateway to WC Available Gateways
 * 
 * @since 1.0.0
 * @param array $gateways all available WC gateways
 * @return array $gateways all WC gateways + GlobalPAY gateway
 */
function wc_GlobalPAY_add_to_gateways( $gateways ) {
	$gateways[] = 'WC_Gateway_GlobalPAY';
	return $gateways;
}
add_filter( 'woocommerce_payment_gateways', 'wc_GlobalPAY_add_to_gateways' );


/**
 * Adds plugin page links
 * 
 * @since 1.0.0
 * @param array $links all plugin links
 * @return array $links all plugin links + our custom links (i.e., "Settings")
 */
function wc_GlobalPAY_gateway_plugin_links( $links ) {

	$plugin_links = array(
		'<a href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=GlobalPAY_gateway' ) . '">' . __( 'Configure', 'wc-gateway-GlobalPAY' ) . '</a>'
	);

	return array_merge( $plugin_links, $links );
}
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'wc_GlobalPAY_gateway_plugin_links' );


/**
 * GlobalPAY Payment Gateway
 *
 * Provides an GlobalPAY Payment Gateway; mainly for testing purposes.
 * We load it later to ensure WC is loaded first since we're extending it.
 *
 * @class 		WC_Gateway_GlobalPAY
 * @extends		WC_Payment_Gateway
 * @version		1.0.0
 * @package		WooCommerce/Classes/Payment
 * @author 		SkyVerge
 */
add_action( 'plugins_loaded', 'wc_GlobalPAY_gateway_init', 0 );

function wc_GlobalPAY_gateway_init() {

	class WC_Gateway_GlobalPAY extends WC_Payment_Gateway {

		/**
		 * Constructor for the gateway.
		 */
		public function __construct() {
	  
	  		$this->GlobalPayID        = "GPZENTEST001";
			$this->id                 = 'GlobalPAY_gateway';
			$this->icon               = apply_filters('woocommerce_GlobalPAY_icon', '');
			$this->has_fields         = false;
			$this->method_title       = __( 'GlobalPAY', 'wc-gateway-GlobalPAY' );
			$this->method_description = __( 'Allows GlobalPAY payments.', 'wc-gateway-GlobalPAY' );
		         $this->return_url = add_query_arg('wc-api', 'wc_globalpay', home_url('/')); //Only using server hosted
            $this->liveurl = 'https://www.zenithbank.com.gh/api.globalpay/api/Pay';
            $this->testurl = 'https://www.zenithbank.com.gh/api.globalpay/api/sandbox/Test';
            // Create plugin fields and settings
			
			// Load the settings.
			$this->init_form_fields();
			$this->init_settings();
		  
		   // Get setting values
            foreach ($this->settings as $key => $val) {
                $this->$key = $val;
            }
			// Define user set variables
			$this->title        = $this->get_option( 'title' );
			$this->description  = $this->get_option( 'description' );
			$this->instructions = $this->get_option( 'instructions', $this->description );
		  
			// Actions
			add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
			add_action( 'woocommerce_thankyou_' . $this->id, array( $this, 'thankyou_page' ) );
			// Customer Emails
			add_action( 'woocommerce_email_before_order_table', array( $this, 'email_instructions' ), 10, 3 );
		}
	
	
		/**
		 * Initialize Gateway Settings Form Fields
		 */
		public function init_form_fields() {
	  
			$this->form_fields = apply_filters( 'wc_GlobalPAY_form_fields', array(
		  
				'enabled' => array(
					'title'   => __( 'Enable/Disable', 'wc-gateway-GlobalPAY' ),
					'type'    => 'checkbox',
					'label'   => __( 'Enable GlobalPAY Payment', 'wc-gateway-GlobalPAY' ),
					'default' => 'no'
				),
				
				'title' => array(
					'title'       => __( 'Title', 'wc-gateway-GlobalPAY' ),
					'type'        => 'text',
					'description' => __( 'This controls the title for the payment method the customer sees during checkout.', 'wc-gateway-GlobalPAY' ),
					'default'     => __( 'GlobalPAY Payment', 'wc-gateway-GlobalPAY' ),
					'desc_tip'    => true,
				),
				
				'description' => array(
					'title'       => __( 'Description', 'wc-gateway-GlobalPAY' ),
					'type'        => 'textarea',
					'description' => __( 'Payment method description that the customer will see on your checkout.', 'wc-gateway-GlobalPAY' ),
					'default'     => __( 'Payment successfully processed.', 'wc-gateway-GlobalPAY' ),
					'desc_tip'    => true,
				),
				
				'instructions' => array(
					'title'       => __( 'Instructions', 'wc-gateway-GlobalPAY' ),
					'type'        => 'textarea',
					'description' => __( 'Instructions that will be added to the thank you page and emails.', 'wc-gateway-GlobalPAY' ),
					'default'     => '',
					'desc_tip'    => true,
				),
				'GlobalPayID' => array(
                    'title' => __('GlobalPay ID', 'woocommerce'),
                    'type' => 'text',
                    'description' => __('', 'woocommerce'),
                    'default' => ''
                    ),                
                'gz_order_status' => array(
                    'title' => __('Order Status', 'woocommerce'),                    
                    'type' => 'select',
                    'description' => __('If you selling digital product you should set to 2 .', 'woocommerce'),
                    'options' => array('1' => 'Processing', '2' => 'Completed'),
                    'default' => '1',
                    ),
                'testmode' => array(
                    'title' => __('Test Mode', 'woocommerce'),
                    'label' => __('Enable Test', 'woocommerce'),
                    'type' => 'checkbox',
                    'description' => __('Process transactions in Test Mode via the Test account  .', 'woocommerce'),
                    'default' => 'no'
                    )
			) );
		}
	
	
		/**
		 * Output for the order received page.
		 */
		public function thankyou_page() {
			if ( $this->instructions ) {
				echo wpautop( wptexturize( $this->instructions ) );
			}
		}
	
	
		/**
		 * Add content to the WC emails.
		 *
		 * @access public
		 * @param WC_Order $order
		 * @param bool $sent_to_admin
		 * @param bool $plain_text
		 */
		public function email_instructions( $order, $sent_to_admin, $plain_text = false ) {
		
			if ( $this->instructions && ! $sent_to_admin && $this->id === $order->payment_method && $order->has_status( 'on-hold' ) ) {
				echo wpautop( wptexturize( $this->instructions ) ) . PHP_EOL;
			}
		}
	
	
		/**
		 * Process the payment and return the result
		 *
		 * @param int $order_id
		 * @return array
		 */
		public function process_payment( $order_id )
		{
	
			$order = wc_get_order( $order_id );
			
			 $url = $this->liveurl;                                        
                    $amount = (float)($order->order_total); // ."00";
                    $card_number_type = isset($_POST['gz_card_type']) ? $_POST['gz_card_type'] : '';
                    $card_number = isset($_POST['gz_card_number']) ? $_POST['gz_card_number'] : '';
                    $card_csc = isset($_POST['gz_card_csc']) ? $_POST['gz_card_csc'] : '';
                    $card_exp_month = isset($_POST['gz_card_expiration_month']) ? $_POST['gz_card_expiration_month'] : '';
                    $expirationYear = isset($_POST['gz_card_expiration_year']) ? $_POST['gz_card_expiration_year'] : '';
                    if (strlen($expirationYear) == 4)
                        $expirationYear = substr($expirationYear, 2, 4);
                    if ($this->testmode == 'yes') {
                        $url = $this->testurl;
                    }

                    $obj = new RootObject();
					$obj->paymentRequest->merchant->GlobalPayID = $this->GlobalPayID;
					$obj->paymentRequest->card->CardNumber = $card_number;
					$obj->paymentRequest->card->CardExpiryMonth  =$card_exp_month;
					$obj->paymentRequest->card->CardExpiryYear = $expirationYear;
					$obj->paymentRequest->card->CardCvv=$card_csc;
					$obj->paymentRequest->payment->Description  = "test";
					$obj->paymentRequest->payment->ReferenceID = "REF_0000".$order_id;
					$obj->paymentRequest->payment->OrderID = $order_id;
					$obj->paymentRequest->payment->Amount  = $amount;
					$obj->paymentRequest->mode = $card_number_type;

					$data_string = json_encode($obj);
                     try
                     {
                     	$ch = curl_init($url);
	                    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
	                    curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);                                                               
	                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);  
	                    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);                                                                    
	                    curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                          
	                        'Content-Type: application/json',                                                                                
	                        'Content-Length: ' . strlen($data_string))                                                                       
	                    );
					
						$response = curl_exec($ch);
						$responOBJ = json_decode($response);
						//var_dump($response);
                        //$responOBJ = json_decode($responOBJ);
                        if ($responOBJ->PaymentResponse->PaymentStatus == "approved" || $responOBJ->PaymentResponse->PaymentStatus == "Approved")
                        {
                        	$order->add_order_note(__('GlobalPAY Zenithbank payment completed', 'woocommerce') .
                        ' (REF ID: ' . $responOBJ->PaymentResponse->referenceID  . ')');
                        	// Mark as on-hold (we're awaiting the payment)
								$order->update_status( 'successfull', __( 'Payment successfull', 'wc-gateway-GlobalPAY' ) );
								
								// Reduce stock levels
								$order->reduce_order_stock();
								// Remove cart
								WC()->cart->empty_cart();
								
								// Return thankyou redirect
								return array(
									'result' 	=> 'success',
									'redirect'	=> $this->get_return_url( $order )
								);
                         			$order->payment_complete();
                         			if($this->gz_order_status == 2) 
                         			{
			                        // Mark order as refunded COMPLETED
			                        $order->update_status('completed', __('Payment completed', 'woocommerce'));
			                    	}
                        }

                        if ($responOBJ->PaymentResponse->PaymentStatus == "vbv required")
							{
								$paymentURL = $responOBJ->PaymentResponse->reason;
		                        header( "Location: ".$paymentURL  );
							}
		                else
                        {
                        	$cancelNote = __('GlobalPAY Zenithbank  payment failed', 'woocommerce') . ' (REF ID: ' .
                        $responOBJ->PaymentResponse->referenceID . '). ' . __('Payment was rejected due to an error',
                        'woocommerce') . ': "' . $responOBJ->PaymentResponse->Reason . '". ';

                    $order->add_order_note($cancelNote);

                    wc_add_notice(__('Payment error', 'woocommerce') . ': ' . $responOBJ->PaymentResponse->Reason . '','error');
                        }


                     }
                      catch (exception $e) {
                    wc_add_notice(__('There was a connection error', 'woocommerce') . ': "' . $e->getMessage() . '"');
                    return;
                }

			
		}
		
		/**
         * Admin Panel Options 
         * - Options for bits like 'title' and availability on a country-by-country basis
         */
        function admin_options()
        {
            ?>
            <h3><?php _e('GlobalPAY Zenithbank', 'woocommerce'); ?></h3>
            <p>
            <?php _e('GlobalPAY Zenithbank works by adding credit card fields on the checkout and then sending the details to GlobalPAY Zenithbank for verification.',
                        'woocommerce'); ?>
            </p>
            <table class="form-table">
            <?php $this->
            generate_settings_html(); ?>
            </table>
            <!--/.form-table-->
            <?php
        }

  
  function payment_fields()
        {           

                //Merchant hosted
                if ($this->testmode == 'yes') {
                    _e('<strong>TEST MODE/ Bank ENABLED</strong>', 'woocommerce');                    
                }
                if ($this->description)
                    echo wpautop(wptexturize($this->description));                
            ?> 
            <fieldset>
                <p class="form-row form-row-first">
                    <label for=""><?php echo __("Credit Card Type", 'woocommerce') ?>
                    <span class="required">*</span></label>
                    <select name="gz_card_type" id="cc-card-type">
                        <option value="visa"><?php _e('Visa', 'woocommerce') ?></option>
                        <option value="mastercard"><?php _e('MasterCard', 'woocommerce') ?></option>
                    </select>                    
                </p>
                <p class="form-row form-row-first">
                    <label for="gz_card_number"><?php echo __("Credit Card number", 'woocommerce') ?>
                    <span class="required">*</span></label>
                    <input type="text" class="input-text" name="gz_card_number"/>
                </p>
                <div class="clear">
                </div>
                <p class="form-row form-row-first">
                    <label for="cc-expire-month"><?php echo __("Expiration date", 'woocommerce') ?>
                    <span class="required">*</span></label>
                    <select name="gz_card_expiration_month" id="cc-expire-month">
                        <option value=""><?php _e('Month', 'woocommerce') ?></option>
                        <?php
                            $months = array();
                            for ($i = 1; $i <= 12; $i++) {
                                $timestamp = mktime(0, 0, 0, $i, 1);
                                $months[date('m', $timestamp)] = date('F', $timestamp);
                            }
                            foreach ($months as $num =>
                         $name) { printf('
                        <option value="%s">%s</option>
                        ', $num, $name); } ?>
                    </select>
                    <select name="gz_card_expiration_year" id="cc-expire-year">
                        <option value=""><?php _e('Year', 'woocommerce') ?></option>
                        <?php
                            $years = array();
                            for ($i = date('Y'); $i <= date('Y') + 15; $i++) {
                                printf('<option value="%u">
                        %u</option>
                        ', $i, $i); } ?>
                    </select>
                </p>
                <p class="form-row form-row-last">
                    <label for="gz_card_csc"><?php _e("Card security code", 'woocommerce') ?>
                    <span class="required">*</span></label>
                    <input type="text" class="input-text" id="gz_card_csc" name="gz_card_csc" maxlength="4" style="width:90px"/>
                    <span class="help gz_card_csc_description"></span>
                </p>
                <div class="clear"></div>
            </fieldset>         
            <?php            
        }// end \WC_Gateway_GlobalPAY class
	}
}